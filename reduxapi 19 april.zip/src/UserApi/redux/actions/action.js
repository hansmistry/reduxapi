import axios from "axios"
import { Getdata } from "../types/types"


export const Getapidata=()=>{
    return (dispatch)=>{
        axios.get("https://student-api.mycodelibraries.com/api/user/get").then((res)=>{
            console.log(res.data.data)
            dispatch({type:Getdata,data:res.data.data})
        })
    }
}

export const Adddata=(obj)=>{
    console.log(obj)
    return (dispatch)=>{
        axios.post("https://student-api.mycodelibraries.com/api/user/add",obj).then((res)=>{
            console.log(res.data)
            dispatch(Getapidata)
        })
    }
}