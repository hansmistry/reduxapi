export const GETAPIDATA="GETAPIDATA"
export const ADDDATA="adddata"