import logo from "./logo.svg";
import "./App.css";
import { BrowserRouter, Route, Router, Routes } from "react-router-dom";
import Formapi from "../src/ApiForm/Coomponet/Formapi";
import Tableapi from "./ApiForm/Coomponet/Tableapi";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route to="/form" element={<Formapi />} />
          <Route to="/table" element={<Tableapi />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
