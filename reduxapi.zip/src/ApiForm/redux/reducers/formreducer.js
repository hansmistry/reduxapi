const dfstate = {
    array: []
}


export const formreducer = (state = dfstate, action) => {
    console.log(state, action);
    switch (action.type) {
        case 'add':

            return state;

        default:
            return state;
    }
}