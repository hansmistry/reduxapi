import React, { useState } from "react";
import Hoc from "./Hoc";

function Formapi() {
    const [obj, setObj] = useState({hobbies:[]})

    let submitForm=()=>{

    }

    let getdatform=()=>{

    }
  return (
    <>
      <form action="" className="w-75 mx-auto shadow-lg p-3 mt-3 ">
        <label className="d-block">First Name</label>
        <input
          type="text"
          name="firstName"
          className="w-100"
          onChange={getdatform}
          value={obj.firstName}
        />
        <label className="d-block">lastName</label>
        <input
          type="text"
          name="lastName"
          className="w-100"
          onChange={getdatform}
          value={obj.lastName}
        />
        <label className="d-block">age</label>
        <input
          type="number"
          name="age"
          className="w-100"
          onChange={getdatform}
          value={obj.age}
        />
        <label className="d-block">city</label>
        <input
          type="text"
          name="city"
          className="w-100"
          onChange={getdatform}
          value={obj.city}
        />
        <label className="d-block">gender</label>
        <input
          type="radio"
          name="gender"
          className=""
          onChange={getdatform}
          value={"male"}
          checked={obj.gender === "male"}
        />{" "}
        male
        <input
          type="radio"
          name="gender"
          className=""
          value={"female"}
          onChange={getdatform}
          checked={obj.gender === "female"}
        />
        female <br />
        <label className="d-block">hobbies</label>
        <input
          type="checkbox"
          value={"football"}
          name="hobbies"
          className=""
          onChange={getdatform}
          checked={obj.hobbies.includes("football")}
        />{" "}
        football
        <input
          type="checkbox"
          name="hobbies"
          value={"cricket"}
          className=""
          onChange={getdatform}
          checked={obj.hobbies.includes("cricket")}
        />{" "}
        cricket
        <input
          type="checkbox"
          name="hobbies"
          value={"basketball"}
          className=""
          onChange={getdatform}
          checked={obj.hobbies.includes("basketball")}
        />
        basketball <br />
        <label className="d-block">Profile</label>
        <input type="file" name="image" onChange={getdatform} /> <br />
        <br />
        <button className="btn btn-primary" type="button" onClick={submitForm}>
          Save
        </button>
      </form>
    </>
  );
}

export default Hoc(Formapi)
