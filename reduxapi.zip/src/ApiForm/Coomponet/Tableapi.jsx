import React from "react";
import Hoc from "./Hoc";

function Tableapi() {
  return (
    <>
      <table className="table">
        <thead>
          <tr>
            <th>file</th>
            <th>firstName</th>
            <th>lastName</th>
            <th>age</th>
            <th>City</th>
            <th>gender</th>
            <th>Hobbies</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
         
        </tbody>
      </table>
    </>
  );
}

export default Hoc(Tableapi);
